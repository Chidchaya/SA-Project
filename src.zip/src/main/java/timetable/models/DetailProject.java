package timetable.models;

public class DetailProject extends DetailGeneralBasic {
    private String projectLeader;

    public DetailProject(String title, String date, String startTime, String endTime,
                         String priority, String status, String category, String projectLeader) {
        super(title, date, startTime, endTime, priority, status, category);
        this.projectLeader = projectLeader;
    }

    public String getProjectLeader() { return projectLeader; }

    public void setProjectLeader(String projectLeader) { this.projectLeader = projectLeader; }

    public void update(String title, String date, String startTime, String endTime,
                       String priority, String status, String category, String projectLeader) {
        setTitle(title);
        setDate(date);
        setStartTime(startTime);
        setEndTime(endTime);
        setPriority(priority);
        setStatus(status);
        setCategory(category);
        setProjectLeader(projectLeader);
    }

    @Override
    public String toString() {
        return "DetailProject{" +
                "projectLeader='" + projectLeader + '\'' +
                '}';
    }
}
