package timetable.models;

public class DetailWeekly extends DetailGeneralBasic {
    private String checkDayOfTheWeek;

    public DetailWeekly(String title, String date, String startTime, String endTime,
                        String priority, String status, String category, String checkDayOfTheWeek) {
        super(title, date, startTime, endTime, priority, status, category);
        this.checkDayOfTheWeek = checkDayOfTheWeek;
    }

    public String getCheckDayOfTheWeek() {
        return checkDayOfTheWeek;
    }

    public void setCheckDayOfTheWeek(String checkDayOfTheWeek) {
        this.checkDayOfTheWeek = checkDayOfTheWeek;
    }

    public void update(String title, String date, String startTime, String endTime,
                       String priority, String status, String category, String checkDayOfTheWeek) {
        setTitle(title);
        setDate(date);
        setStartTime(startTime);
        setEndTime(endTime);
        setPriority(priority);
        setStatus(status);
        setCategory(category);
        setCheckDayOfTheWeek(checkDayOfTheWeek);
    }
}


