package timetable.models;

import timetable.controllers.GeneralList;
import timetable.services.GeneralReadWrite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

public class WorkList {
    private ArrayList<DetailGeneralBasic> generalBasicArrayList;
    private ArrayList<DetailWeekly> weeklyArrayList;
    private ArrayList<DetailForward> forwardArrayList;
    private ArrayList<DetailProject> projectArrayList;
    private ArrayList<DetailCategory> categoryArrayList;

    public WorkList() throws IOException {
        generalBasicArrayList = new ArrayList<>();
        weeklyArrayList = new ArrayList<>();
        forwardArrayList = new ArrayList<>();
        projectArrayList = new ArrayList<>();
        categoryArrayList = new ArrayList<>();
    }

    public void addGeneral(DetailGeneralBasic generalBasic) {
        generalBasicArrayList.add(generalBasic);
    }
    public void addWeekly(DetailWeekly weekly) {weeklyArrayList.add(weekly);}
    public void addForward(DetailForward forward) {forwardArrayList.add(forward);}
    public void addProject(DetailProject project) {projectArrayList.add(project);}
    public void addCategory(DetailCategory category) {categoryArrayList.add(category);}

    public ArrayList<DetailGeneralBasic> toGeneralList() {
        return generalBasicArrayList;
    }
    public ArrayList<DetailWeekly> toWeeklyList() {
        return weeklyArrayList;
    }
    public ArrayList<DetailForward> toForwardList()  {
        return forwardArrayList;
    }
    public ArrayList<DetailProject> toProjectList() {
        return projectArrayList;
    }
    public ArrayList<DetailCategory> toCategoryList() {return categoryArrayList; }

    public ArrayList<DetailGeneralBasic> toListGeneral() {
        ArrayList<DetailGeneralBasic> list = new ArrayList<>();
        for (DetailGeneralBasic general:generalBasicArrayList) {
            if (general.getClass() == DetailGeneralBasic.class) {
                list.add((DetailGeneralBasic) general);
            }
        }
        return list;
    }

    public ArrayList<DetailWeekly> toListWeekly() {
        ArrayList<DetailWeekly> list = new ArrayList<>();
        for (DetailWeekly weekly:weeklyArrayList) {
            if (weekly.getClass() == DetailWeekly.class) {
                list.add((DetailWeekly) weekly);
            }
        }
        return list;
    }

    public ArrayList<DetailForward> toListForward() {
        ArrayList<DetailForward> list = new ArrayList<>();
        for (DetailForward forward:forwardArrayList) {
            if (forward.getClass() == DetailForward.class) {
                list.add((DetailForward) forward);
            }
        }
        return list;
    }

    public ArrayList<DetailProject> toListProject() {
        ArrayList<DetailProject> list = new ArrayList<>();
        for (DetailProject project:projectArrayList) {
            if (project.getClass() == DetailProject.class) {
                list.add((DetailProject) project);
            }
        }
        return list;
    }

    public ArrayList<DetailCategory> toListCategory() {
//        ArrayList<DetailCategory> list = new ArrayList<>();
//        for (DetailCategory category:categoryArrayList) {
//            if (category.getClass() == DetailCategory.class) {
//                list.add((DetailCategory) category);
//            }
//        }
//        return list;
        return categoryArrayList;
    }

    public boolean checkNameGeneral(String name) {
        for(DetailGeneralBasic detailGeneralBasic : generalBasicArrayList) {
            if (detailGeneralBasic.getTitle().equals(name)) {
                return false;
            }
        }
        return true;
    }

    public boolean checkNameWeekly(String name) {
        for(DetailWeekly detailWeekly : weeklyArrayList) {
            if (detailWeekly.getTitle().equals(name)) {
                return false;
            }
        }
        return true;
    }

    public boolean checkNameForward(String name) {
        for(DetailForward detailForward : forwardArrayList) {
            if (detailForward.getTitle().equals(name)) {
                return false;
            }
        }
        return true;
    }

    public boolean checkWorkerName(String workerName) {
        for(DetailForward detailForward : forwardArrayList) {
            if (detailForward.getWorkerName().equals(workerName)) {
                return false;
            }
        }
        return true;
    }

    public boolean checkNameProject(String name) {
        for(DetailProject detailProject : projectArrayList) {
            if (detailProject.getTitle().equals(name)) {
                return false;
            }
        }
        return true;
    }

    public boolean checkNameCategory(String name) {
        for(DetailCategory detailCategory: categoryArrayList) {
            if (detailCategory.getNameCategory().equals(name)) {
                return false;
            }
        }
        return true;
    }

    public ArrayList<DetailGeneralBasic> generalCount (String category) {
        ArrayList<DetailGeneralBasic> general = new ArrayList<>();
        for (DetailGeneralBasic g : generalBasicArrayList) {
            if (g.getCategory().equals(category)) {
                general.add(g);
            }
        }
        return general;
    }

    public ArrayList<DetailWeekly> weeklyCount (String category) {
        ArrayList<DetailWeekly> weekly = new ArrayList<>();
        for (DetailWeekly w : weeklyArrayList) {
            if (w.getCategory().equals(category)) {
                weekly.add(w);
            }
        }
        return weekly;
    }

    public ArrayList<DetailForward> forwardCount (String category) {
        ArrayList<DetailForward> forward = new ArrayList<>();
        for (DetailForward f : forwardArrayList) {
            if (f.getCategory().equals(category)) {
                forward.add(f);
            }
        }
        return forward;
    }

    public ArrayList<DetailProject> projectCount (String category) {
        ArrayList<DetailProject> project = new ArrayList<>();
        for (DetailProject p : projectArrayList) {
            if (p.getCategory().equals(category)) {
                project.add(p);
            }
        }
        return project;
    }
}
