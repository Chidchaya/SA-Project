package timetable.controllers;

import com.github.saacsos.FXRouter;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import timetable.models.*;
import timetable.services.*;

import java.io.IOException;
import java.util.ArrayList;

public class AllListController {
    private DataSource dataGeneral;
    private WorkList listGeneral;
    private ObservableList<DetailGeneralBasic> generalObservableList;

    private DataSource dataWeekly;
    private WorkList listWeekly;
    private ObservableList<DetailWeekly> weeklyObservableList;

    private DataSource dataForward;
    private WorkList listForward;
    private ObservableList<DetailForward> forwardsObservableList;

    private DataSource dataProject;
    private WorkList listProject;
    private ObservableList<DetailProject> projectObservableList;

    private DetailCategory categoryTask;
    private DataSource dataSource;
    private WorkList listCategory;
    private ObservableList<DetailCategory> categoryObservableList;

    @FXML private TableView<DetailGeneralBasic> infoGeneralTable;
    @FXML private TableView<DetailWeekly> infoWeeklyTable;
    @FXML private TableView<DetailForward> infoForwardTable;
    @FXML private TableView<DetailProject> infoProjectTable;
    @FXML private TableView<DetailCategory> infoCategoryTable;

    @FXML Button updateGeneral, updateWeekly, updateForward, updateProject;

    @FXML
    private ImageView background;

    @FXML
    public void initialize() {
        background.setImage(new Image("/images/Background 5.png"));
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                dataGeneral = new GeneralReadWrite("data", "general.csv");
                listGeneral = dataGeneral.getData();
                showDataGeneral();
            }
        });

        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                dataWeekly = new WeeklyReadWrite("data", "weekly.csv");
                listWeekly = dataWeekly.getData();
                showDataWeekly();
            }
        });

        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                dataForward = new ForwardReadWrite("data", "forward.csv");
                listForward = dataForward.getData();
                showDataForward();
            }
        });

        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                dataProject = new ProjectReadWrite("data", "project.csv");
                listProject = dataProject.getData();
                showDataProject();
            }
        });

        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                dataSource = new CategoryReadWrite("data","category.csv");
                listCategory = dataSource.getData();
                showDataCategory();
            }
        });
    }

    private void showDataGeneral() {
        generalObservableList = FXCollections.observableArrayList(listGeneral.toGeneralList());
        infoGeneralTable.setItems(generalObservableList);

        ArrayList<StringConfig> configs = new ArrayList<>();
        configs.add(new StringConfig("title:Name", "field:title"));
        configs.add(new StringConfig("title:Date", "field:date"));
        configs.add(new StringConfig("title:Start-Time", "field:startTime"));
        configs.add(new StringConfig("title:Finish-Time", "field:endTime"));
        configs.add(new StringConfig("title:Priority", "field:priority"));
        configs.add(new StringConfig("title:Status", "field:status"));
        configs.add(new StringConfig("title:Category", "field:category"));

        for (StringConfig conf : configs) {
            TableColumn col = new TableColumn(conf.get("title"));
            col.setCellValueFactory(new PropertyValueFactory<>(conf.get("field")));
            infoGeneralTable.getColumns().add(col);
            col.setSortType(TableColumn.SortType.DESCENDING);
        }
    }

    private void showDataWeekly() {
        weeklyObservableList = FXCollections.observableArrayList(listWeekly.toListWeekly());
        infoWeeklyTable.setItems(weeklyObservableList);

        ArrayList<StringConfig> configs = new ArrayList<>();
        configs.add(new StringConfig("title:Name", "field:title"));
        configs.add(new StringConfig("title:Date", "field:date"));
        configs.add(new StringConfig("title:Start-Time", "field:startTime"));
        configs.add(new StringConfig("title:Finish-Time", "field:endTime"));
        configs.add(new StringConfig("title:Priority", "field:priority"));
        configs.add(new StringConfig("title:Status", "field:status"));
        configs.add(new StringConfig("title:Category", "field:category"));
        configs.add(new StringConfig("title:Day of the Week", "field:checkDayOfTheWeek"));


        for (StringConfig conf : configs) {
            TableColumn col = new TableColumn(conf.get("title"));
            col.setCellValueFactory(new PropertyValueFactory<>(conf.get("field")));
            infoWeeklyTable.getColumns().add(col);
            col.setSortType(TableColumn.SortType.DESCENDING);
        }
    }

    private void showDataForward() {
        forwardsObservableList = FXCollections.observableArrayList(listForward.toForwardList());
        infoForwardTable.setItems(forwardsObservableList);

        ArrayList<StringConfig> configs = new ArrayList<>();
        configs.add(new StringConfig("title:Name", "field:title"));
        configs.add(new StringConfig("title:Date", "field:date"));
        configs.add(new StringConfig("title:Start-Time", "field:startTime"));
        configs.add(new StringConfig("title:Finish-Time", "field:endTime"));
        configs.add(new StringConfig("title:Priority", "field:priority"));
        configs.add(new StringConfig("title:Status", "field:status"));
        configs.add(new StringConfig("title:Category", "field:category"));
        configs.add(new StringConfig("title:Worker Name", "field:workerName"));
        configs.add(new StringConfig("title:Forwarding Format", "field:forwardingFormat"));
        configs.add(new StringConfig("title:File Extension", "field:fileExtension"));


        for (StringConfig conf : configs) {
            TableColumn col = new TableColumn(conf.get("title"));
            col.setCellValueFactory(new PropertyValueFactory<>(conf.get("field")));
            infoForwardTable.getColumns().add(col);
            col.setSortType(TableColumn.SortType.DESCENDING);
        }
    }

    private void showDataProject() {
        projectObservableList = FXCollections.observableArrayList(listProject.toListProject());
        infoProjectTable.setItems(projectObservableList);

        ArrayList<StringConfig> configs = new ArrayList<>();
        configs.add(new StringConfig("title:Name", "field:title"));
        configs.add(new StringConfig("title:Date", "field:date"));
        configs.add(new StringConfig("title:Start-Time", "field:startTime"));
        configs.add(new StringConfig("title:Finish-Time", "field:endTime"));
        configs.add(new StringConfig("title:Priority", "field:priority"));
        configs.add(new StringConfig("title:Status", "field:status"));
        configs.add(new StringConfig("title:Category", "field:category"));
        configs.add(new StringConfig("title:Project Leader", "field:projectLeader"));

        for (StringConfig conf : configs) {
            TableColumn col = new TableColumn(conf.get("title"));
            col.setCellValueFactory(new PropertyValueFactory<>(conf.get("field")));
            infoProjectTable.getColumns().add(col);
            col.setSortType(TableColumn.SortType.DESCENDING);
        }
    }

    private void showDataCategory() {
        categoryObservableList = FXCollections.observableArrayList(listCategory.toListCategory());
        infoCategoryTable.setItems(categoryObservableList);

        ArrayList<StringConfig> configs = new ArrayList<>();
        configs.add(new StringConfig("title:Name Category", "field:nameCategory"));
//        configs.add(new StringConfig("title:All Work", "field:numOfWorks"));


        for (StringConfig conf : configs) {
            TableColumn col = new TableColumn(conf.get("title"));
            col.setCellValueFactory(new PropertyValueFactory<>(conf.get("field")));
            col.prefWidthProperty().bind(infoCategoryTable.widthProperty().multiply(1.0));
            infoCategoryTable.getColumns().add(col);
            col.setSortType(TableColumn.SortType.DESCENDING);
        }
    }

    @FXML
    public void handleBackAllListToToHomeButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("home");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Home ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleUpdateGeneralButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("general List");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า General List ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleUpdateWeeklyButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("weekly List");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Weekly List ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleUpdateForwardButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("forward List");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Forward List ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleUpdateProjectButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("project List");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Project List ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleToCategoryButton(javafx.event.ActionEvent actionEvent) {
        try {
            FXRouter.goTo("category");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Category ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }
}
