package timetable.controllers;

import com.github.saacsos.FXRouter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import timetable.services.PDFFileDataSource;

import java.io.IOException;

public class HomeController {

    @FXML Button creatorButton, information;
    @FXML Button generalJobButton, weeklyJobButton, forwardJobButton, projectJobButton;
    @FXML Button generalListButton, weeklyListButton, forwardListButton, projectListButton;
    @FXML Button allList;

    @FXML
    private ImageView background;

    @FXML
    public  void initialize() {
        background.setImage(new Image("/images/Background.png"));
    }

    @FXML
    private void handlePDFButton() throws IOException {
        PDFFileDataSource pdfFileDataSource = new PDFFileDataSource("PDF File", "6210450067.pdf");
        pdfFileDataSource.openPDFFile();
    }

    @FXML
    public void handleToGeneralJobButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("general");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า General Job ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleHomeToGeneralListButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("general List");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า General List ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleToHomeToWeeklyJobButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("weekly");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Weekly Job ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleHomeToWeeklyListButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("weekly List");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Weekly List ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleToHomeToForwardJobButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("forward");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Forward Job ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleHomeToForwardListButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("forward List");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Forward List ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleToProjectJobButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("project");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Project Job ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleHomeToProjectListButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("project List");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Project List ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleToCreatorButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("creator");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Creator ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleAllListButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("all List");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า All List ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleBackToStartButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("start");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Start ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }

    @FXML
    public void handleHomeToCategoryButton(ActionEvent actionEvent) {
        try {
            FXRouter.goTo("category");
        } catch (IOException e) {
            System.err.println("ไปที่หน้า Category ไม่ได้");
            System.err.println("ให้ตรวจสอบการกำหนด route");
        }
    }
}

